"""단일 소스에서 호스트별 패키지를 생성하고 실제 진입점을 검사합니다."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import re


NAME = "geminitogenius"
MANIFEST = "gtg-manifest.json"


def copy_source(source: Path, target: Path):
    for path in sorted(source.rglob("*")):
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        if path.is_symlink():
            raise ValueError("패키지 원본에 심볼릭 링크가 있습니다.")
        if path.is_file():
            dest = target / path.relative_to(source)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, dest)


def build(source: Path, target: Path, installed: Path, platform: str) -> dict:
    if platform not in {"antigravity", "gemini-cli"}:
        raise ValueError("지원하지 않는 패키지 호스트입니다.")
    if target.exists() and any(target.iterdir()):
        raise ValueError("패키지 생성 대상은 비어 있어야 합니다.")
    target.mkdir(parents=True, exist_ok=True)
    copy_source(source / "gtg", target / "gtg")
    copy_source(source / "profile/skills", target / "skills")
    shutil.copyfile(source / "scripts/gtg_runner.py", target / "run.py")
    rules = (source / "profile/rules/gtg.md").read_text(encoding="utf-8")
    command = "python3 " + shlex.quote(str(installed / "run.py")) + " hook " + platform + " "
    if platform == "antigravity":
        (target / "rules").mkdir()
        (target / "rules/AGENTS.md").write_text(rules, encoding="utf-8")
        (target / "plugin.json").write_text(json.dumps({"name": NAME}) + "\n")
        hooks = {"gtg-context": {"PreInvocation": [{"type": "command", "command": command + "PreInvocation", "timeout": 5}]},
                 "gtg-completion": {"Stop": [{"type": "command", "command": command + "Stop", "timeout": 5}]}}
        hook_file = target / "hooks.json"
    else:
        (target / "GEMINI.md").write_text(rules.split("---\n", 2)[-1].lstrip(), encoding="utf-8")
        version = (source / "VERSION").read_text().strip()
        (target / "gemini-extension.json").write_text(json.dumps({"name": NAME, "version": version, "contextFileName": "GEMINI.md"}) + "\n")
        hooks = {"hooks": {event: [{"hooks": [{"type": "command", "name": "gtg-" + event.lower(),
                                               "command": command + event, "timeout": 5000}]}]
                           for event in ("BeforeAgent", "AfterAgent")}}
        hook_file = target / "hooks/hooks.json"
        hook_file.parent.mkdir()
    hook_file.write_text(json.dumps(hooks, indent=2) + "\n")
    files = {path.relative_to(target).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in sorted(target.rglob("*")) if path.is_file()}
    manifest = {"schema_version": 1, "name": NAME, "platform": platform,
                "version": (source / "VERSION").read_text().strip(), "installed_path": str(installed), "files": files}
    (target / MANIFEST).write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def verify(target: Path, execute_hooks: bool = True) -> dict:
    manifest = json.loads((target / MANIFEST).read_text())
    expected = manifest["files"]
    if manifest["platform"] == "antigravity" and "rules/AGENTS.md" not in expected:
        raise ValueError("호스트가 읽는 기본 규칙 진입점이 없습니다.")
    actual = {path.relative_to(target).as_posix(): path for path in target.rglob("*")
              if path.is_file() and path.name != MANIFEST and "__pycache__" not in path.parts and path.suffix != ".pyc"}
    if set(actual) != set(expected):
        raise ValueError("패키지 파일 목록이 manifest와 다릅니다.")
    for name, path in actual.items():
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected[name]:
            raise ValueError(f"패키지 원문이 변경되었습니다: {name}")
        if path.suffix == ".py":
            ast.parse(path.read_text(encoding="utf-8"))
        if path.name == "SKILL.md":
            text = path.read_text(encoding="utf-8")
            match = re.match(r"\A---\nname: ([a-z0-9]+(?:-[a-z0-9]+)*)\ndescription: ([^\n]+)\n---\n", text)
            if not match or match[1] != path.parent.name or len(match[1]) > 64 or len(match[2]) > 1024:
                raise ValueError(f"스킬 메타데이터가 올바르지 않습니다: {name}")
    if not execute_hooks:
        return {"ok": True, "files": len(actual), "hooks_executed": 0}
    platform = manifest["platform"]
    hooks = json.loads((target / ("hooks.json" if platform == "antigravity" else "hooks/hooks.json")).read_text())
    count = 0
    if platform == "antigravity":
        entries = [(event, handler) for named in hooks.values() for event, handlers in named.items() for handler in handlers]
    else:
        entries = [(event, handler) for event, groups in hooks["hooks"].items() for group in groups for handler in group["hooks"]]
    for event, handler in entries:
        argv = shlex.split(handler["command"])
        if len(argv) != 5 or argv[:1] != ["python3"] or argv[1] != str(Path(manifest["installed_path"]) / "run.py"):
            raise ValueError("훅 실행 경로가 패키지 경로와 다릅니다.")
        # 설치 전에는 동일한 진입점을 staging 경로에서 실행합니다.
        argv[1] = str(target / "run.py")
        payload = ({"conversationId": "package-check", "workspacePaths": [str(target)], "invocationNum": 0,
                    "executionNum": 0, "fullyIdle": True, "terminationReason": "model_stop"}
                   if platform == "antigravity" else
                   {"session_id": "package-check", "cwd": str(target), "hook_event_name": event, "stop_hook_active": False})
        process = subprocess.run(argv, input=json.dumps(payload), text=True, capture_output=True, timeout=5,
                                 env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        if process.returncode or process.stderr.strip():
            raise ValueError("패키지 훅 실행이 실패했습니다.")
        output = json.loads(process.stdout)
        if not isinstance(output, dict):
            raise ValueError("훅 출력이 JSON 객체가 아닙니다.")
        if event == "Stop" and output.get("decision") != "stop":
            raise ValueError("작업 없는 종료 훅이 종료를 허용하지 않습니다.")
        if event == "PreInvocation" and not output.get("injectSteps"):
            raise ValueError("첫 호출의 세션 정보가 없습니다.")
        if event == "BeforeAgent" and not output.get("hookSpecificOutput", {}).get("additionalContext"):
            raise ValueError("첫 요청의 세션 정보가 없습니다.")
        count += 1
    if count != 2:
        raise ValueError("필수 컨텍스트·완료 훅이 누락됐습니다.")
    return {"ok": True, "files": len(actual), "hooks_executed": count, "platform": platform}
