"""등록된 명령을 직접 실행하여 현재 파일 상태에 대한 증거를 만듭니다."""

from __future__ import annotations

import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from .spec import fingerprint
from .store import Store


def terminate(process: subprocess.Popen):
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    else:
        process.kill()
    process.wait()


def execute(store: Store, task_id: str, check_id: str) -> dict:
    task = store.task(task_id)
    checks = {check["id"]: check for check in task["spec"]["checks"]}
    if check_id not in checks:
        raise ValueError("등록되지 않은 검사입니다.")
    check = checks[check_id]
    workspace = Path(task["workspace"])
    before = fingerprint(workspace, check["watch"])
    run_id = store.begin(task_id, check_id)
    started = time.monotonic()
    process = None
    result = {"status": "error", "returncode": None, "before": before, "after": None}
    try:
        # 출력은 호스트에 바로 전달하며 상태 DB에 원문을 보관하지 않습니다.
        process = subprocess.Popen(check["argv"], cwd=workspace, stdin=subprocess.DEVNULL,
                                   stdout=sys.stderr, stderr=sys.stderr, start_new_session=os.name == "posix")
        store.attach_process(run_id, process.pid)
        try:
            code = process.wait(timeout=check.get("timeout_seconds", 120))
        except subprocess.TimeoutExpired:
            terminate(process)
            result.update(status="timeout", returncode=process.returncode)
        else:
            result.update(status="passed" if code == 0 else "failed", returncode=code)
        after = fingerprint(workspace, check["watch"])
        result["after"] = after
        if result["status"] == "passed" and before != after:
            result["status"] = "changed_during_check"
    except KeyboardInterrupt:
        if process is not None:
            terminate(process)
        result["status"] = "interrupted"
        raise
    except (OSError, ValueError) as error:
        result.update(status="error", error_type=type(error).__name__)
    finally:
        result["duration_seconds"] = round(time.monotonic() - started, 6)
        store.finish(run_id, result)
    return result


def status(store: Store, task_id: str) -> dict:
    task = store.task(task_id)
    latest = store.latest(task_id)
    checks = []
    for check in task["spec"]["checks"]:
        run = latest.get(check["id"])
        state = "pending"
        if run:
            state = "running" if run["running"] else run["result"]["status"]
            if state == "passed":
                try:
                    current = fingerprint(Path(task["workspace"]), check["watch"])
                    if current != run["result"].get("after"):
                        state = "stale"
                except (OSError, ValueError):
                    state = "stale"
        checks.append({"id": check["id"], "criterion": check["criterion"], "status": state})
    return {"task_id": task_id, "goal": task["spec"]["goal"],
            "verified": all(check["status"] == "passed" for check in checks), "checks": checks}
