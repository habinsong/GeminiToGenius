"""에이전트가 사용하는 로컬 작업·검증 명령입니다."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sqlite3

from .runner import execute, status
from .sessions import Sessions, key
from .spec import sensitive
from .store import Store


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path)
    commands = parser.add_subparsers(dest="command", required=True)
    start = commands.add_parser("start", help="완료 조건을 고정한 작업을 시작합니다.")
    start.add_argument("--workspace", type=Path, default=Path.cwd())
    start.add_argument("--spec", type=Path, required=True)
    start.add_argument("--platform", choices=("antigravity", "gemini-cli"))
    start.add_argument("--session")
    verify = commands.add_parser("verify", help="등록된 검증 명령을 직접 실행합니다.")
    verify.add_argument("task_id")
    verify.add_argument("--check")
    for name in ("status", "recover"):
        command = commands.add_parser(name)
        command.add_argument("task_id")
    for name in ("pause", "resume"):
        command = commands.add_parser(name)
        command.add_argument("--platform", choices=("antigravity", "gemini-cli"), required=True)
        command.add_argument("--session", required=True)
        if name == "pause":
            command.add_argument("--reason", required=True)
    args = parser.parse_args()
    store = None
    try:
        state_root = args.workspace.resolve(strict=True) if args.command == "start" else Path.cwd()
        state_path = (args.state or state_root / ".gtg/state.sqlite3").absolute()
        store = Store(state_path)
        if args.command == "start":
            if sensitive(args.spec) or any(p.is_symlink() for p in [args.spec, *args.spec.parents]):
                raise ValueError("민감 경로나 심볼릭 링크를 작업 명세로 읽지 않습니다.")
            spec = json.loads(args.spec.read_text(encoding="utf-8"))
            if bool(args.platform) != bool(args.session):
                raise ValueError("호스트와 세션은 함께 지정해야 합니다.")
            task_id = store.create(args.workspace, spec)
            if args.session:
                Sessions(store).bind(key(args.platform, args.session), task_id)
            result = status(store, task_id)
        elif args.command == "verify":
            checks = store.task(args.task_id)["spec"]["checks"]
            ids = [args.check] if args.check else [check["id"] for check in checks]
            for check_id in ids:
                outcome = execute(store, args.task_id, check_id)
                if outcome["status"] != "passed":
                    break
            result = status(store, args.task_id)
        elif args.command == "recover":
            result = {"recovered": store.recover(args.task_id), **status(store, args.task_id)}
        elif args.command in {"pause", "resume"}:
            sessions = Sessions(store)
            session = key(args.platform, args.session)
            if args.command == "pause":
                sessions.pause(session, args.reason)
            else:
                sessions.resume(session)
            result = {"ok": True, "paused": args.command == "pause"}
        else:
            result = status(store, args.task_id)
        result["state_path"] = str(state_path)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return int(args.command == "verify" and not result["verified"])
    except (OSError, ValueError, sqlite3.Error) as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False))
        return 1
    except KeyboardInterrupt:
        print(json.dumps({"ok": False, "error": "사용자가 검사를 중단했습니다."}, ensure_ascii=False))
        return 130
    finally:
        if store is not None:
            store.close()


if __name__ == "__main__":
    raise SystemExit(main())
