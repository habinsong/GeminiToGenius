"""호스트 세션과 로컬 작업을 연결하고 자동 재개의 상한을 관리합니다."""

from __future__ import annotations

import hashlib
import re

from .store import Store
from .runner import status


def key(platform: str, session_id: str) -> str:
    if platform not in {"antigravity", "gemini-cli"}:
        raise ValueError("지원하지 않는 호스트입니다.")
    if not isinstance(session_id, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{1,128}", session_id):
        raise ValueError("호스트 세션 식별자가 올바르지 않습니다.")
    return hashlib.sha256(f"{platform}:{session_id}".encode()).hexdigest()


class Sessions:
    def __init__(self, store: Store):
        self.store = store
        self.db = store.connection
        self.db.execute("""CREATE TABLE IF NOT EXISTS sessions (
            key TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id),
            paused INTEGER NOT NULL DEFAULT 0, retries INTEGER NOT NULL DEFAULT 0,
            last_event TEXT, reason TEXT NOT NULL DEFAULT ''
        )""")
        self.db.commit()

    def bind(self, session_key: str, task_id: str):
        self.store.task(task_id)
        with self.db:
            existing = self.get(session_key)
            if (existing and existing["task_id"] != task_id and not existing["paused"]
                    and not status(self.store, existing["task_id"])["verified"]):
                raise ValueError("다른 활성 작업이 있습니다. 이전 작업을 명시적으로 해제하세요.")
            # 같은 작업에 대한 재시도는 기존 상한과 중단 상태를 유지합니다.
            self.db.execute("INSERT INTO sessions(key, task_id) VALUES (?, ?) ON CONFLICT(key) DO NOTHING",
                            (session_key, task_id))
            if existing and existing["task_id"] != task_id:
                self.db.execute("UPDATE sessions SET task_id=?, paused=0, retries=0, last_event=NULL, reason='' WHERE key=?",
                                (task_id, session_key))

    def get(self, session_key: str) -> dict | None:
        row = self.db.execute("SELECT * FROM sessions WHERE key=?", (session_key,)).fetchone()
        return dict(row) if row else None

    def pause(self, session_key: str, reason: str):
        if not reason.strip():
            raise ValueError("중단 이유가 필요합니다.")
        with self.db:
            cursor = self.db.execute("UPDATE sessions SET paused=1, reason=? WHERE key=?", (reason[:500], session_key))
            if cursor.rowcount != 1:
                raise ValueError("연결된 작업이 없습니다.")

    def resume(self, session_key: str):
        with self.db:
            cursor = self.db.execute("UPDATE sessions SET paused=0, retries=0, last_event=NULL, reason='' WHERE key=?", (session_key,))
            if cursor.rowcount != 1:
                raise ValueError("연결된 작업이 없습니다.")

    def nudge(self, session_key: str, event_id: str) -> bool:
        # 중복 이벤트와 동시에 도착한 종료 요청도 한 번만 처리합니다.
        with self.db:
            cursor = self.db.execute("""UPDATE sessions SET retries=retries+1, last_event=?
                WHERE key=? AND paused=0 AND retries<2 AND (last_event IS NULL OR last_event<>?)""",
                                     (event_id, session_key, event_id))
            return cursor.rowcount == 1
