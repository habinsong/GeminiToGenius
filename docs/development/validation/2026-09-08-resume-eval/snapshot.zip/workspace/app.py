from exports import to_csv, to_json


DOWNLOAD_STEM = "현장 기록"


def download(records, format="json"):
    if format == "json":
        return {
            "filename": DOWNLOAD_STEM + ".json",
            "media_type": "application/json; charset=utf-8",
            "content": to_json(records),
        }
    if format == "csv":
        return {
            "filename": DOWNLOAD_STEM + ".csv",
            "media_type": "text/csv; charset=utf-8",
            "content": to_csv(records),
        }
    raise ValueError("unsupported format")
